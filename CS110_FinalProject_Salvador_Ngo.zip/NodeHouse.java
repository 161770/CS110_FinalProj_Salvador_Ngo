/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* Salvador, Miguel - 161770

I have not discussed the Java language code 
in my program with anyone
other than my instructor or the teaching
assistants assigned to this course.

I have not used Java language code 
obtained from another student, or
any other unauthorized source, either 
modified or unmodified.

If any Java language
code or documentation used in my program was
obtained from another source, such as a text
book or course notes, those have been clearly
noted with a proper citation in the 
comments of my code. */
import java.io.*;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.*;
public class NodeHouse {
    LinkedList<Node> NodeHouse;
    int number;
    NodeHouse(){
        NodeHouse = new LinkedList<>();
        this.number = 0;
    }
    public void Commands(RandomAccessFile rafbt, RandomAccessFile rafval, long record){ 
        
        Scanner in = new Scanner(System.in);
        String command = in.nextLine();
        
        String[] com = command.split(" ");
        
        if(com[0].equals("insert")) {
            try{
                
            Insert(com[1],com[2],rafval, rafbt,record);}
            catch (ArrayIndexOutOfBoundsException  ae){
                
                try{
                    Insert(com[1],"",rafval, rafbt,record);
            }catch (Exception ze){
                System.out.println("ERROR: invalid command.");
            }
            
        }
        }
        else if(com[0].equals("update")) Update(com[1],com[2],rafval,rafbt);
        else if(com[0].equals("select")) Select(com[1],rafval,rafbt,record);
        else if(com[0].equals("exit")) Exit(rafval);
        else System.out.println("ERROR: invalid command.");
        Commands(rafbt,rafval,record);
    }
    
    public  void Insert(String a, String b, RandomAccessFile RAF,RandomAccessFile RAFbt, long record){
        int key = Integer.parseInt(a);
        
        String val = b;    
        int search = (int)record/4;
        
        
        //Write to Value File
        try{
            //Write Records
            RAF.seek(0);
            record=RAF.readLong();
            
            //Write Size and Value
            
            byte[] ar = val.getBytes();
            try{
                
                RAF.seek(8+(record)*256);
                RAF.readShort();
                RAF.seek(8+(record)*256);
                if(RAF.readShort()>0){
                System.out.printf("ERROR: %d already exists.\n",key);}
                else{
                    RAF.seek(8+(record)*256);
                    RAF.writeShort(ar.length);
                    RAF.seek(8+1+(record)*256);
                    RAF.write(ar);
                    System.out.printf("%s inserted at %d \n", val,key);
                }
            }catch(IOException za){
                RAF.writeShort(ar.length);
                RAF.seek(8+1+(record)*256);
                RAF.write(ar);
                System.out.printf("%s inserted at %d \n", val,key);
                
        //-------------------------------------------------------------------------------
        
        //Write to BT File
        
        try{
            RAFbt.seek(0);
            RAFbt.writeLong(number+1);
            RAFbt.seek(8);
            RAFbt.writeLong(record);
            
            for(int h = 2;h<=11;h+=3){
                RAFbt.seek(16+((search)*112)+(8*h));
                
                if(RAFbt.readLong()==-1&&(h==5||h==2||h==8||h==11)){
                    RAFbt.seek(16+((search)*112)+(8*h));
                    //NodeHouse.get(number).node.set(h,(long)key);
                    RAFbt.writeLong(key);
                    //NodeHouse.get(number).node.set(h+1,(long)record);
                    RAFbt.seek(16+(8*(h+1))+((search)*112));
                    RAFbt.writeLong(record);
                    break;
                }
                }
            
            RAF.seek(0);
            RAF.writeLong(record);
        }catch (IOException ae)
            {
                System.out.println("Writing new Node");
                
                NodeHouse.add(new Node());
                number = search;
                
                try{
                    RAFbt.seek(0);
                    RAFbt.writeLong(record);
                    RAFbt.seek(8);
                    RAFbt.writeLong(record);
                    
 
            for(int h = 0;h<14;h++){
                RAFbt.seek(16+((search)*112)+(8*h));
                //NodeHouse.get(number).node.add((long)-1);
                RAFbt.writeLong(((long) -1));
                }
            for(int h = 2;h<=11;h+=3){
                RAFbt.seek(16+((search)*112)+(8*h));    
                if(RAFbt.readLong()==-1&&(h==5||h==2||h==8||h==11)){
                    RAFbt.seek(16+((search)*112)+(8*h));
                    //NodeHouse.get(number).node.set(h,(long)key);
                    RAFbt.writeLong(key);
                    RAFbt.seek(16+((search)*112)+(8*(h+1)));
                    //NodeHouse.get(number).node.set(h+1,(long)record);
                    RAFbt.writeLong(record);
                    break;
                }
                }
            
            
            
                }catch(IOException vc){
                        System.out.println("File not found");
                        }
                }
            }
        record+=1;   
        RAF.seek(0);
            RAF.writeLong(record);
        }catch(IOException ae){
            System.out.println("IO Error at Insert");
        }

        Commands(RAFbt,RAF,record);
    }
    public  void Update(String a, String b, RandomAccessFile RAF,RandomAccessFile RAFbt){
        int key = Integer.parseInt(a);
        String val = b;
        long offset=0;
        byte[] ar = val.getBytes();
        try{
                offset = Search(key, RAFbt);
                
                RAF.seek(8+(offset)*256);
                RAF.readShort();
                RAF.seek(8+(offset)*256);
                if(RAF.readShort()>0){
                    RAF.seek(8+(offset)*256);
                    RAF.writeShort(ar.length);
                    RAF.seek(8+1+(offset)*256);
                    RAF.write(ar);
                    System.out.printf("%s inserted at %d \n", val,key);
                }
                else{
                    System.out.printf("ERROR: %d does not exists.\n",key);}
                
            }catch(IOException za){
                
                System.out.printf("ERROR: %d does not exists.\n",key);
        
    }}
    public  void Select(String a, RandomAccessFile RAF,RandomAccessFile rafbt, long record){
        int key = Integer.parseInt(a);
        long offset=0;
        offset = Search(key, rafbt);    
       
       try{
        byte[] be = new byte[RAF.readShort()];
        RAF.seek(8+1+(offset)*256);
        RAF.read(be);
        String se = new String(be,StandardCharsets.UTF_8);
        System.out.println(se);
        Commands(rafbt,RAF,record);
    }catch(IOException z){
        
    }
    }
    public long Search(int key,RandomAccessFile rafbt){
        
        long offset=0;
        
        try{
            rafbt.seek(0);
            long search = rafbt.readLong();
            for (long z = 0;z<search;z++){
                for(long node = 0;node<14;node++){
                    rafbt.seek(16+((z)*112)+(8*node));
                    
                    long asd = rafbt.readLong();
                    if((long)key == asd){
                        rafbt.seek(16+(z*112)+(8*(node+1)));
                            offset = rafbt.readLong();
                            
                            return offset;
                            
                        }
                    }
                }}catch(IOException ae){
                    System.out.printf("ERROR: %d does not exists.\n",key);}
        return 0;
    }
    public  void Exit(RandomAccessFile RAF){
        
        try{
            System.out.println("Exiting");
        RAF.close();
       
        }catch(IOException ae){
            System.out.println("Error at Exit");
        }
        
    }
}
