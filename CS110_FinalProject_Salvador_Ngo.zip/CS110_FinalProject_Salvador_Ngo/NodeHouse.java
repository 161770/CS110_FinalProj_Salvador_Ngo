/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* Salvador, Miguel - 161770

I have not discussed the Java language code 
in my program with anyone
other than my instructor or the teaching
assistants assigned to this course.

I have not used Java language code 
obtained from another student, or
any other unauthorized source, either 
modified or unmodified.

If any Java language
code or documentation used in my program was
obtained from another source, such as a text
book or course notes, those have been clearly
noted with a proper citation in the 
comments of my code. */
import java.io.*;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.*;
public class NodeHouse {
    LinkedList<Node> NodeHouse;
    int number;

    public static final int REC_START = 8; 
    public static final int SIZE = 256; 
    public static final int START = 0; 
    public static final String ADD = "insert"; 
    public static final String UPD = "update"; 
    public static final String SEL = "select"; 
    public static final String QUIT = "exit"; 
    public static final String ERR_IC = "ERROR: invalid command."; 
    public static final int BT_START = 2; 
    public static final int INC = 3; 
    public static final int MAX_DATA = 5; 
    public static final int NODELEN = 3 * MAX_DATA - 1; 
    public static final int NODEBYTES = NODELEN * 8; 

    NodeHouse(){
        NodeHouse = new LinkedList<>();
        this.number = 0;
    }

    //performs indicated operation
    public void Commands(RandomAccessFile rafbt, RandomAccessFile rafval, long record){ 
        
        Scanner in = new Scanner(System.in);
        String command = in.nextLine();
        
        String[] com = command.split(" ");
        String b = "";
        for(int i=2;i<com.length;i++){
            if (i==com.length-1) b+=com[i];
            else b+=com[i]+" ";
        }
        if(com[0].equals(ADD)) {
            try{
                
            Insert(com[1],b,rafval, rafbt,record);}
            catch (ArrayIndexOutOfBoundsException  ae){
                
                try{
                    Insert(com[1],"",rafval, rafbt,record);
            }catch (Exception ze){
                System.out.println(ERR_IC);
            }
            
        }
        }
        else if(com[0].equals(UPD)) Update(com[1],b,rafval,rafbt);
        else if(com[0].equals(SEL)) Select(com[1],rafval,rafbt,record);
        else if(com[0].equals(QUIT)) Exit(rafval, rafbt);
        else System.out.println(ERR_IC);
        Commands(rafbt,rafval,record);
    }
    
    public  void Insert(String a, String b, RandomAccessFile RAF,RandomAccessFile RAFbt, long record){
        int key = Integer.parseInt(a);
        
        String val = b;    
        int search = (int)record/4;
        
        
        //Write to Value File
        try{
            //Write Records
            RAF.seek(START);
            record=RAF.readLong();
            
            //Write Size and Value
            
            byte[] ar = val.getBytes();
            try{
                //access location of key
                RAF.seek(REC_START+(record)*SIZE);
                RAF.readShort();
                RAF.seek(REC_START+(record)*SIZE);
                //display error if it empty 
                if(RAF.readShort()>0){
                System.out.printf("ERROR: %d already exists.\n",key);}
                else{
                    //display confirmation message that the record has been stored in the indicated key
                    RAF.seek(REC_START+(record)*SIZE);
                    RAF.writeShort(ar.length);
                    RAF.seek(REC_START+1+(record)*SIZE);
                    RAF.write(ar);
                    System.out.printf("%d inserted.\n", key);
                }
            }catch(IOException za){
                RAF.writeShort(ar.length);
                RAF.seek(REC_START+1+(record)*SIZE);
                RAF.write(ar);
                System.out.printf("%d inserted.\n", key);
                
        //-------------------------------------------------------------------------------
        
        //Write to BT File
        
        try{
            //write down record and number of nodes
            RAFbt.seek(START);
            RAFbt.writeLong(number);
            RAFbt.seek(REC_START);
            RAFbt.writeLong(record);
            
            //check if key exists in any of the nodes
            //write to node when no such key exists
            for(int h = BT_START;h<=11;h+=INC){
                RAFbt.seek(16+((search)*NODEBYTES)+(REC_START*h));
                
                if(RAFbt.readLong()==-1&&(h==5||h==3||h==8||h==11)){
                    RAFbt.seek(16+((search)*NODEBYTES)+(REC_START*h));
                    //NodeHouse.get(number).node.set(h,(long)key);
                    RAFbt.writeLong(key);
                    //NodeHouse.get(number).node.set(h+1,(long)record);
                    RAFbt.seek(16+(REC_START*(h+1))+((search)*NODEBYTES));
                    RAFbt.writeLong(record);
                    break;
                }
                }
            
            RAF.seek(0);
            RAF.writeLong(record);
        }catch (IOException ae)
            {
                
                NodeHouse.add(new Node());
                number = search;
                
                try{
                    RAFbt.seek(START);
                    RAFbt.writeLong(record);
                    RAFbt.seek(REC_START);
                    RAFbt.writeLong(record);
                    
 
            for(int h = 0;h<NODELEN;h++){
                RAFbt.seek(16+((search)*NODEBYTES)+(REC_START*h));
                //NodeHouse.get(number).node.add((long)-1);
                RAFbt.writeLong(((long) -1));
                }
            for(int h = BT_START;h<=11;h+=INC){
                RAFbt.seek(16+((search)*NODEBYTES)+(REC_START*h));    
                if(RAFbt.readLong()==-1&&(h==5||h==3||h==8||h==11)){
                    RAFbt.seek(16+((search)*NODEBYTES)+(REC_START*h));
                    //NodeHouse.get(number).node.set(h,(long)key);
                    RAFbt.writeLong(key);
                    RAFbt.seek(16+((search)*NODEBYTES)+(REC_START*(h+1)));
                    //NodeHouse.get(number).node.set(h+1,(long)record);
                    RAFbt.writeLong(record);
                    break;
                }
                }
            
            
            
                }catch(IOException vc){
                        System.out.println("File not found");
                    }
                }
            }
        record+=1;   
        RAF.seek(0);
            RAF.writeLong(record);
        }catch(IOException ae){
            System.out.println("IO Error at Insert");
        }

        Commands(RAFbt,RAF,record);
    }
    //change the record that is contained in the given key 
    public  void Update(String a, String b, RandomAccessFile RAF,RandomAccessFile RAFbt){
        int key = Integer.parseInt(a);
        String val = b;
        long offset=0;
        byte[] ar = val.getBytes();
        try{
                offset = Search(key, RAFbt);
                //go to key's location
                RAF.seek(REC_START+(offset)*SIZE);
                RAF.readShort();
                RAF.seek(REC_START+(offset)*SIZE);
                //replace the data in key 
                if(RAF.readShort()>0){
                    RAF.seek(REC_START+(offset)*SIZE);
                    RAF.writeShort(ar.length);
                    RAF.seek(REC_START+1+(offset)*SIZE);
                    RAF.write(ar);
                    System.out.printf("%d updated.\n", key);
                }
                else{
                    //print error if no such key exists
                    System.out.printf("ERROR: %d does not exist.\n",key);}
                
            }catch(IOException za){
                
                System.out.printf("ERROR: %d does not exist.\n",key);
        
    }}
    //display record contained in given key
    public  void Select(String a, RandomAccessFile RAF,RandomAccessFile rafbt, long record){
        int key = Integer.parseInt(a);
        long offset=0;
        offset = Search(key, rafbt);    

       //find location of key
       try{
        RAF.seek(REC_START+(offset)*SIZE);
        byte[] be = new byte[RAF.readShort()];
        RAF.seek(REC_START+1+(offset)*SIZE);
        //get key and convert it to utf 8 
        RAF.read(be);
        String se = new String(be,StandardCharsets.UTF_8);
        System.out.println(key + " => " + se);
        Commands(rafbt,RAF,record);
    }catch(IOException z){
        
    }
    }
    //method that will find the node
    public long Search(int key,RandomAccessFile rafbt){
        
        long offset=0;
        
        try{
            rafbt.seek(0);
            long search = rafbt.readLong();
            for (long z = 0;z<search;z++){
                for(long node = 0;node<NODELEN;node++){
                    rafbt.seek(16+((z)*NODEBYTES)+(REC_START*node));
                    
                    long asd = rafbt.readLong();
                    if((long)key == asd){
                        rafbt.seek(16+(z*NODEBYTES)+(REC_START*(node+1)));
                            offset = rafbt.readLong();
                            
                            return offset;
                            
                        }
                    }
                }}catch(IOException ae){
                    System.out.printf("ERROR: %d does not exist.\n",key);}
        return 0;
    }
    //method that closes the randomaccessfile
    public  void Exit(RandomAccessFile RAF, RandomAccessFile RAFbt){
        
        try{
            System.out.println("Exiting");
        RAF.close();
        RAFbt.close(); 
       
        }catch(IOException ae){
            System.out.println("Error at Exit");
        }
        
    }
}
