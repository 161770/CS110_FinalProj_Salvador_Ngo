/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* Salvador, Miguel - 161770

I have not discussed the Java language code 
in my program with anyone
other than my instructor or the teaching
assistants assigned to this course.

I have not used Java language code 
obtained from another student, or
any other unauthorized source, either 
modified or unmodified.

If any Java language
code or documentation used in my program was
obtained from another source, such as a text
book or course notes, those have been clearly
noted with a proper citation in the 
comments of my code. */
import java.util.*;
import java.io.File;
import java.io.RandomAccessFile; 
import java.io.*;
import java.nio.charset.StandardCharsets;

public class BTreeDB {
    
    public static void main(String args[]) throws FileNotFoundException {
        NodeHouse main = new NodeHouse();
        
        RandomAccessFile rafbt = new RandomAccessFile(args[0], "rwd"); 
        RandomAccessFile rafval = new RandomAccessFile(args[1], "rwd"); 
        long record = 0;
        File f = new File(args[0]);
        if(f.exists() && !f.isDirectory()) {
            try{
                record = rafval.readLong();
                long nodes = new Long(rafbt.readLong());
                for(int i=0;i<nodes;i++){
                    main.NodeHouse.add(new Node());
                    for(int h = 0;h<14;h++){
                        rafbt.seek(16+(i*112)+(8*h));
                       // main.NodeHouse.get((int)nodes).node.add(rafbt.readLong());
                    }
                    //Node.InSortVal(main.NodeHouse.get((int)nodes).node);
                    //Node.InSortChild(main.NodeHouse.get((int)nodes).node);
                    
                }
            }catch(IOException ae){
                try{
                    //main.NodeHouse.add(new Node());
                    rafval.writeLong(record);
                    rafbt.writeLong(record);
                }catch (IOException az){
                    System.out.println("Error");
                }
            }
            }
            else{
                
            }
        
        main.Commands(rafbt,rafval,record);
        }
        
    
    
    
    
}

