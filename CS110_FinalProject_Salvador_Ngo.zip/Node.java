/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* Salvador, Miguel - 161770

I have not discussed the Java language code 
in my program with anyone
other than my instructor or the teaching
assistants assigned to this course.

I have not used Java language code 
obtained from another student, or
any other unauthorized source, either 
modified or unmodified.

If any Java language
code or documentation used in my program was
obtained from another source, such as a text
book or course notes, those have been clearly
noted with a proper citation in the 
comments of my code. */
import java.util.*;
public class Node {
    int number;
    LinkedList<Long> node;
    Node(){
        this.node = new LinkedList<>();
        
    }
    public static LinkedList<Long> InSortVal(LinkedList<Long> S){
        for(int i=2;i<=8;i+=3){
            int lowin = i;
            for(int j = i+3;j<=11;j+=3){
                if(S.get(j)<S.get(lowin)){
                    lowin=j;
                }
            }
            long temp = S.get(lowin);
            long temp1 = S.get(lowin+1);
            S.set(lowin,S.get(i));
            S.set(lowin+1,S.get(i+1));
            S.set(i,temp); 
            S.set(i+1,temp1);
        }
        return S;
    }
    public static LinkedList<Long> InSortChild(LinkedList<Long> S){
        for(int i=1;i<=10;i+=3){
            int lowin = i;
            for(int j = i+3;j<=13;j+=3){
                if(S.get(j)<S.get(lowin)){
                    lowin=j;
                }
            }
            long temp = S.get(lowin);
            S.set(lowin,S.get(i));
            S.set(i,temp);
        }
        return S;
    }
}
